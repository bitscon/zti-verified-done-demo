"""zticli — the `zti` product CLI (Power Move #1, ADR-0004).

Distinct from the repo's unrelated terraform `cli/` and from the open
runtime's `ztip` console script (D11: `ztip` = open envelope runtime,
`zti` = closed product CLI)."""
