# ZTI Core License

Copyright (c) 2026 Chad McCormack / Zero Trust Intelligence. All rights reserved.

This is a commercial license, written in plain language. It is not an open-source
license. It covers **ZTI Core** — the ZTIP Gate enforcement node, the enforcement
engine, the CLI, and the control-plane software delivered as a runnable build
(together, "the Software"). ZTI Core is delivered as a **runnable container, not as
source code.**

---

## How it's delivered and priced

ZTI Core ships as a runnable build. You do not receive its source code. Every
install includes a **free 30-day trial** with full functionality. When the trial
ends, the Software **locks** until a paid license is applied — a valid license
turns it back on.

A license is a simple annual fee, per organization, sold in yearly terms:

- **ZTI Core (base): US $495 per year.**
- **Fleet Intelligence add-on: +US $249 per year.**
- **Auditor Evidence Pack add-on: +US $349 per year.**

Add-ons are optional and priced à la carte; base is required. Terms of **1, 2, or 5
years** are available, with **5% off** a 2-year term and **10% off** a 5-year term.
Licensing is yearly only — there is no monthly plan and no per-use metering.

One license covers the whole organization — unlimited gates, agents, and
environments within it. An organization means your company and the entities under
its common control; contractors working in your repositories are covered. A paid
license includes all updates released during your license term and email support —
a human replies. Licenses are refundable in full within 30 days of payment.

**Payment** is by invoice or payment link — your choice. To buy or ask a licensing
question, contact: licensing@zerotrustintelligence.io.

---

## What you may not do

- Use the Software after the trial ends without a paid license.
- Resell, sublicense, or offer the Software (or a service whose primary value is the
  Software's functionality) to third parties without a separate written agreement.
- Attempt to defeat, remove, or circumvent the trial or license enforcement.
- Remove or alter copyright, license, or attribution notices.
- Use the "Zero Trust Intelligence" or "ZTI" names, marks, or logos without written
  permission. All rights in those names and marks are reserved.

---

## The open protocol

Two related works are **not** covered by this license and are fully open:

- The **ZTIP protocol specification**, and
- The **ztip reference runtime**

are released under the MIT License in their own repository. You may use them freely
under MIT terms. This license covers only ZTI Core — the closed gate and
control-plane product.

---

## No warranty

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE, AND NONINFRINGEMENT. You are responsible for validating that the
Software's policy enforcement meets your requirements before relying on it.

## Limitation of liability

IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES,
OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT, OR OTHERWISE, ARISING
FROM, OUT OF, OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Termination

This license terminates automatically if you breach it. On termination you must stop
using the Software. The no-warranty, liability, and trademark sections survive
termination.

---

*Questions about licensing? Ask before you buy — the 30-day trial is always free.*
