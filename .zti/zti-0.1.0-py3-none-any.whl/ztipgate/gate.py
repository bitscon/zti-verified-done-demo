"""ZTI Core reference gate — the licensed control layer for AI coding agents.

This is the piece the open protocol *describes* and the sandboxing tools do NOT
implement: it governs an agent's work as a leased, contract-bound unit, refuses
to accept "done" without independently re-verifying it, and stamps a
hash-chained ZTIP receipt. Fail-closed by construction.

Commercial-use licensed (free for individuals / non-commercial; companies
license it to run in production). Depends only on the open `ztip` runtime for
canonicalization, hashing, and receipts — so nothing here is a secret; the
money is the license, not concealment.
"""

from __future__ import annotations

import fnmatch
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

# Make the open `ztip` runtime importable without an install (found relative to
# this file). In production `ztip` is a normal pip dependency.
for _up in Path(__file__).resolve().parents:
    if (_up / "ztip" / "ztip" / "__init__.py").exists():
        sys.path.insert(0, str(_up / "ztip"))
        break

from ztip.hashing import CANONICALIZATION, HASH_ALGORITHM, envelope_hash  # noqa: E402

ALLOW, DENY, ESCALATE = "allow", "deny", "escalate"

# Irreversible, high-blast-radius operations — the verbs behind the real 2025
# incidents. These route to a hard block regardless of path scope.
IRREVERSIBLE = re.compile(
    r"(rm\s+-rf|drop\s+(database|table)|delete[^\n]*\b(database|production|prod)\b"
    r"|truncate\b|force[- ]?push|push\s+--force|wipe\b|format\s+disk|"
    r"reset\s+--hard|delete\s+the\s+database)",
    re.IGNORECASE,
)


@dataclass
class Contract:
    """What a unit of work may touch and what must be true for it to be 'done'."""

    work_id: str
    allowed_paths: list[str]
    forbidden_paths: list[str] = field(default_factory=list)
    required_checks: list[str] = field(default_factory=list)


@dataclass
class Decision:
    decision: str
    reason_code: str
    detail: str


def _match(path: str, patterns: list[str]) -> bool:
    path = path.lstrip("./")
    for raw in patterns:
        pat = raw.lstrip("./")
        if fnmatch.fnmatch(path, pat):
            return True
        if pat.endswith("/") and path.startswith(pat):
            return True
        if path == pat or path.startswith(pat.rstrip("*")):
            return True
    return False


class Gate:
    """A leased, contract-bound governor for one unit of agent work."""

    def __init__(self, contract: Contract):
        self.contract = contract
        self.attempted: list[dict] = []
        self.completed: list[dict] = []
        self.blocked: list[tuple[dict, Decision]] = []
        self._chain: list[dict] = []  # hash-chained decision audit

    # ── enforcement (the "block the reckless action" beat) ──────────────────
    def check_action(self, action: dict) -> Decision:
        """action = {"type", "path", "command"}. Fail-closed on anything risky."""
        self.attempted.append(action)
        command = action.get("command", "") or ""
        path = action.get("path", "") or ""

        if IRREVERSIBLE.search(command) or IRREVERSIBLE.search(path):
            decision = Decision(DENY, "IRREVERSIBLE_ACTION_BLOCKED",
                                 f"irreversible operation refused: {command or path}")
        elif path and _match(path, self.contract.forbidden_paths):
            decision = Decision(DENY, "FORBIDDEN_PATH_WRITE",
                                 f"path is explicitly out of contract scope: {path}")
        elif path and not _match(path, self.contract.allowed_paths):
            decision = Decision(DENY, "OUT_OF_SCOPE",
                                 f"path not in the leased scope: {path}")
        elif not path:
            # A command-only action can't be scoped to the lease. Never silently
            # allow it — escalate for explicit approval (fail-closed).
            decision = Decision(ESCALATE, "UNSCOPED_ACTION",
                                 f"command-only action cannot be scoped to the lease; "
                                 f"requires explicit approval: {command}")
        else:
            decision = Decision(ALLOW, "IN_SCOPE", f"permitted: {path or command}")

        if decision.decision == ALLOW:
            self.completed.append(action)
        else:
            self.blocked.append((action, decision))
        self._record(action, decision)
        return decision

    # ── the differentiator: independent completion verification ─────────────
    def verify_completion(
        self, claimed_status: str, check_runner: Callable[[str], bool]
    ) -> tuple[bool, list[dict], str]:
        """Re-run every required check ourselves. Never trust the agent's word."""
        results: list[dict] = []
        all_passed = True
        for check in self.contract.required_checks:
            passed = bool(check_runner(check))
            results.append({"check": check, "passed": passed, "verifier": "gate-independent"})
            all_passed = all_passed and passed
        accepted = (claimed_status == "succeeded") and all_passed
        reason = "COMPLETION_VERIFIED" if accepted else "COMPLETION_UNVERIFIED"
        return accepted, results, reason

    # ── the tamper-proof ZTIP receipt ───────────────────────────────────────
    def issue_receipt(self, claimed_status: str, accepted: bool,
                      verification_results: list[dict], completion_reason: str) -> dict:
        reason_codes = [] if accepted else [completion_reason]
        reason_codes += [d.reason_code for _, d in self.blocked]
        envelope = {
            "ztap_version": "1.0-draft",
            "envelope_type": "execution_receipt",
            "transaction_id": self.contract.work_id,
            "receipt_id": f"rcpt-{self.contract.work_id}",
            "issued_at": datetime.now(timezone.utc).isoformat(),
            "status": "succeeded" if accepted else "blocked",
            "agent_claimed_status": claimed_status,
            "reason_codes": reason_codes,
            "actions_attempted": [self._summary(a) for a in self.attempted],
            "actions_completed": [self._summary(a) for a in self.completed],
            "actions_blocked": [
                {"action": self._summary(a), "reason_code": d.reason_code, "detail": d.detail}
                for a, d in self.blocked
            ],
            "verification_results": verification_results,
            "verification_authority": "independent-gate",
            "audit_chain_head": self._chain[-1]["hash"] if self._chain else None,
            "integrity": {"canonicalization": CANONICALIZATION, "hash_algorithm": HASH_ALGORITHM},
        }
        envelope["integrity"]["hash_value"] = envelope_hash(envelope)
        return envelope

    # ── hash-chained audit (tamper-evident record of every decision) ────────
    def _record(self, action: dict, decision: Decision) -> None:
        entry = {
            "seq": len(self._chain),
            "action": self._summary(action),
            "decision": decision.decision,
            "reason_code": decision.reason_code,
            "prev_hash": self._chain[-1]["hash"] if self._chain else None,
        }
        entry["hash"] = envelope_hash(entry)
        self._chain.append(entry)

    @property
    def audit_chain(self) -> list[dict]:
        return self._chain

    @staticmethod
    def _summary(action: dict) -> dict:
        return {k: action.get(k) for k in ("type", "path", "command") if action.get(k)}
