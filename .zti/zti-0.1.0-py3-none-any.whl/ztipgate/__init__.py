"""ZTIP Gate — package marker so the gate library is importable as
`ztipgate.gate` (the `zti` CLI mints receipts with it; ADR-0004 §2). The
Tier-1 daemon (core/hook/gated.py) keeps importing `gate` via its own
sys.path insert and is unaffected."""
